# SimpleMathJ

SimpleMathJ is a project of mine that I started to give my newphews a resource to practice simple mathematics like addition, subtraction, multiplication, and division.

It will further be expanded to cover other math topics like calculus and linear algebra. I may also include an elementary language section for preschool education. 
